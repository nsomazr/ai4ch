/*
 Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","vi",{title:"Giao diện người dùng Color Picker",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Tập màu định nghĩa sẵn",config:"Dán chuỗi này vào tập tin config.js của bạn"});