/*
 Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("placeholder","vi",{title:"Thuộc tính đặt chỗ",toolbar:"Tạo đặt chỗ",name:"Tên giữ chỗ",invalidName:"Giữ chỗ không thể để trống và không thể chứa bất kỳ ký tự sau: [,], \x3c, \x3e",pathName:"giữ chỗ"});