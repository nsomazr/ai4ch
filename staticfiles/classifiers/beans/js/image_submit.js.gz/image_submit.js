document.getElementById("img_section_one").onchange = function() {
    // alert("onchange one");
    document.getElementById("form_img_section_one").submit();
    // alert("submit one");
}


// document.getElementById("img_section_two").onchange = function() {
//     alert("onchange two");
//     document.getElementById("form_img_section_two").submit();
//     alert("submit two");
// };