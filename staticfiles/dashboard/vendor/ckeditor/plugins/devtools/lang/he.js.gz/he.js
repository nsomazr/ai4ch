/*
 Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("devtools","he",{title:"מידע על האלמנט",dialogName:"שם הדיאלוג",tabName:"שם הטאב",elementId:"ID של האלמנט",elementType:"סוג האלמנט"});